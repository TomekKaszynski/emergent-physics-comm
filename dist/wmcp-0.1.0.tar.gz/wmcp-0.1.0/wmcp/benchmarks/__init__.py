"""WMCP benchmark suite."""
